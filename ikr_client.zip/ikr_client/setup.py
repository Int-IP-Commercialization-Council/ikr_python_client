from setuptools import setup
import os


setup(name='ikr_client',
      version='1.0.1-alpha',
      description='',
      url='https://github.com/andrii-dubytskyi/ikr_client.git',
      download_url = 'https://github.com/andrii-dubytskyi/ikr_client/archive/master.zip',
      author='Chi Tester',
      author_email='chi.tester@gmail.com',
      license='MIT',
      packages=['ikr_client'],
      install_requires=[
        'six',
        'prompt_toolkit',
        'pysha3',
        'requests',
      ],
      zip_safe=False
)
